<?php include '../../../templates/crudHead.php'?>
<title>Create</title>
</head>
<body>
<section class="container">
    <h2>Create product</h2>
    <a href="create-single.php" class="button">Create a new admin account</a>
</section>
<?php include '../../../templates/footer.php'; ?>
</body>
</html>

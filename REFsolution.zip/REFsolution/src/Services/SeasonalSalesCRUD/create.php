<?php include '../../../templates/crudHead.php'?>
<title>Create</title>
<head>
    <title>Create</title>
    <link rel="stylesheet" href="../../../public/assets/css/main.css">
    <link rel="stylesheet" href="../../../public/assets/css/layout.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<?php
include '../../templates/header.php';
?>
<section class="container">
    <h2>Create New Sale</h2>
    <a href="create-single.php" class="button">Create a new sale</a>
</section>
<?php include '../../../templates/footer.php'; ?>
</body>
</html>

<?php include '../../../templates/crudHead.php'?>
<title>Create Purchase</title>
</head>
<body>
<section class="container">
    <h2>Create a new purchase</h2>
    <a href="create-single.php" class="button">Create a new purchase</a>
</section>
<?php include '../../../templates/footer.php'; ?>
</body>
</html>

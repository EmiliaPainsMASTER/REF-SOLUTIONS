<?php
//Definition of the directory for src/Core
define('SRC_SERVICES_PATH', realpath(__DIR__) . DIRECTORY_SEPARATOR);
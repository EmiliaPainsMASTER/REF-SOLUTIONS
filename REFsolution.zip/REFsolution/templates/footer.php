<footer class="footer">
    <p class="footer_text">&copy; <?php echo date('Y'); ?> REF Solutions</p>
    <div class="social_icons">
        <a href="https://www.instagram.com/" target="_blank" aria-label="Instagram">
            <img src="../public/assets/img/insta.jpg" alt="Instagram" class="icon">
        </a>
        <a href="https://twitter.com/" target="_blank" aria-label="X (Twitter)">
            <img src="../public/assets/img/x.png" alt="X (Twitter)" class="icon">
        </a>
    </div>
</footer>
